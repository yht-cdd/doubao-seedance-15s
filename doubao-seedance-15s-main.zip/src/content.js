// content.js - 内容脚本（Chrome 版）
// 注入 15s 菜单项，验证/重新安装 fetch hook，监听媒体元素

(function () {
  'use strict';

  const PLUGIN_ID = 'doubao-seedance-enhancer';
  let isEnabled = true;
  let targetDuration = 15;
  let isSimulatingClick = false;

  // 维护 DOM data attribute 供 MAIN world 的 inject.js 动态读取 duration
  // （content.js 在 isolated world，window 变量对 MAIN world 不可见，必须用 DOM 共享）
  function setTargetDuration(d) {
    targetDuration = d;
    document.documentElement.setAttribute('data-seedance-duration', String(d));
  }
  document.documentElement.setAttribute('data-seedance-duration', '15');

  console.log(`[${PLUGIN_ID}] content.js 已加载`);

  // ========== 1. 同步时长配置到 inject.js ==========
  function syncDurationConfig() {
    chrome.storage.local.get(['doubao-seedance-enhancer_enabled', 'doubao-seedance-enhancer_duration'], (res) => {
      const wasEnabled = isEnabled;
      isEnabled = res['doubao-seedance-enhancer_enabled'] !== 'off';
      const durationStr = res['doubao-seedance-enhancer_duration'] || '15s';
      const newDuration = parseInt(durationStr) || 15;

      if (wasEnabled && !isEnabled) {
        console.log(`[${PLUGIN_ID}] 插件已禁用，清理 UI`);
        remove15sOption();
        clearDurationButtonPatch();
      }

      if (!wasEnabled && isEnabled) {
        console.log(`[${PLUGIN_ID}] 插件已启用，注入 UI`);
        inject15sOption();
      }

      if (targetDuration === 15 && newDuration !== 15) {
        clearDurationButtonPatch();
      }

      targetDuration = newDuration;
      document.documentElement.setAttribute('data-seedance-duration', String(newDuration));

      window.postMessage({
        type: 'seedance_set_duration',
        payload: { duration: targetDuration, enabled: isEnabled }
      }, '*');
    });
  }
  syncDurationConfig();

  chrome.storage.onChanged.addListener((changes) => {
    if (changes['doubao-seedance-enhancer_enabled'] || changes['doubao-seedance-enhancer_duration']) {
      syncDurationConfig();
    }
  });

  // ========== 2. 验证 fetch hook 状态（inject.js 已在 MAIN world 安装带保护的 hook）==========
  // inject.js 使用 Object.defineProperty(window, 'fetch', { writable: false, configurable: false })
  // 所以 hook 不会被页面覆盖，不需要重装，只需要确认状态

  let hookVerified = false;

  function checkHookStatus() {
    if (!isEnabled || hookVerified) return;
    window.postMessage({ type: 'seedance_check_hook' }, '*');
  }

  window.addEventListener('message', (e) => {
    if (e.data?.type === 'seedance_hook_status') {
      if (e.data.active) {
        hookVerified = true;
        console.log(`[${PLUGIN_ID}] fetch hook 状态确认正常`);
      } else if (isEnabled) {
        console.warn(`[${PLUGIN_ID}] fetch hook 不活跃，请检查 inject.js`);
      }
    }
  });

  // 前 30 秒每 2 秒检查一次，确认 hook 正常后停止
  let hookCheckCount = 0;
  const hookChecker = setInterval(() => {
    hookCheckCount++;
    if (hookVerified || hookCheckCount > 15) {
      clearInterval(hookChecker);
      return;
    }
    checkHookStatus();
  }, 2000);

  setTimeout(() => {
    checkHookStatus();
  }, 500);

  // 监听页面导航（SPA 路由变化）
  // 不用 MutationObserver 监听整个 body（性能差），改用 popstate + 周期检查 URL
  // fetch hook 是在 window 层面的，路由变化不需要重装 hook，只需要重新注入 UI
  let lastUrl = location.href;

  function checkUrlChange() {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      console.log(`[${PLUGIN_ID}] 检测到页面导航，重新注入 UI`);
      if (isEnabled) {
        inject15sOption();
      } else {
        remove15sOption();
      }
    }
  }

  window.addEventListener('popstate', checkUrlChange);
  setInterval(checkUrlChange, 1000);

  // ========== 4. 注入 15s 菜单项 + 维护 UI 显示 ==========
  function remove15sOption() {
    document.querySelectorAll('.seedance-15s-injected').forEach(el => el.remove());
    clearDurationButtonPatch();
  }

  function inject15sOption() {
    if (!isEnabled) return;

    const menus = document.querySelectorAll('[role="menu"]');
    let durationMenu = null;

    for (const menu of menus) {
      const items = menu.querySelectorAll('[role="menuitem"]');
      const texts = Array.from(items).map(i => i.textContent.trim());
      if (texts.includes('5s') && texts.includes('10s')) {
        durationMenu = menu;
        break;
      }
    }

    if (!durationMenu) {
      patchDurationButton();
      return;
    }

    const menuItems = durationMenu.querySelectorAll('[role="menuitem"]');

    // 给原生选项绑定点击监听器（只绑定一次）
    menuItems.forEach(item => {
      const text = item.textContent.trim();
      if (text !== '5s' && text !== '10s') return;
      if (item.dataset.seedanceNativeBound) return;
      item.dataset.seedanceNativeBound = 'true';
      item.addEventListener('click', () => {
        // 只有 10s 需要检查 isSimulatingClick（我们只模拟点击 10s）
        // 5s 不能检查，否则快速从 15s 切到 5s 时会被错误跳过，
        // 导致 targetDuration 还是 15，fetch hook 错误修改 5s 请求为 15s，输入框消失
        if (text === '10s' && isSimulatingClick) return;
        const d = text;
        const dur = parseInt(d) || 10;
        setTargetDuration(dur);
        window.postMessage({
          type: 'seedance_set_duration',
          payload: { duration: dur, enabled: isEnabled }
        }, '*');
        chrome.storage.local.set({ 'doubao-seedance-enhancer_duration': d });
        console.log(`[${PLUGIN_ID}] 用户选择原生 ${d}`);
        // 直接清理覆盖层
        clearDurationButtonPatch();
      });
    });

    if (durationMenu.querySelector('.seedance-15s-injected')) {
      syncMenuCheckmark(durationMenu);
      patchDurationButton();
      return;
    }

    let template = null;
    for (const item of menuItems) {
      if (item.textContent.trim() === '10s') {
        template = item;
        break;
      }
    }
    if (!template) {
      patchDurationButton();
      return;
    }

    const option15s = template.cloneNode(true);
    option15s.classList.add('seedance-15s-injected');

    const walker = document.createTreeWalker(option15s, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      if (walker.currentNode.textContent.trim() === '10s') {
        walker.currentNode.textContent = '15s';
        break;
      }
    }

    // 只移除 svg 勾选标记本身，保留父容器结构
    option15s.querySelectorAll('svg').forEach(svg => svg.remove());

    option15s.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();

      setTargetDuration(15);
      window.postMessage({
        type: 'seedance_set_duration',
        payload: { duration: 15, enabled: isEnabled }
      }, '*');
      chrome.storage.local.set({ 'doubao-seedance-enhancer_duration': '15s' });
      console.log(`[${PLUGIN_ID}] 用户选择 15s，将在请求时修改 duration`);

      // 模拟点击 10s 让豆包内部状态变为 10s（便于 fetch hook 修改 ability_param.duration）
      isSimulatingClick = true;
      for (const item of menuItems) {
        if (item.textContent.trim() === '10s') {
          item.click();
          break;
        }
      }
      // 延迟重置 isSimulatingClick，确保豆包异步触发的 click 事件也被忽略
      setTimeout(() => { isSimulatingClick = false; }, 150);

      // 多次延迟 patch，覆盖豆包的异步 DOM 更新（按钮文字、勾选状态）
      // 最多 300ms，避免过长时间干扰豆包渲染
      const doPatch = () => {
        if (targetDuration !== 15) return;
        syncMenuCheckmark(durationMenu);
        patchDurationButton();
      };
      doPatch();
      setTimeout(doPatch, 50);
      setTimeout(doPatch, 150);
      setTimeout(doPatch, 300);
    });

    durationMenu.appendChild(option15s);
    console.log(`[${PLUGIN_ID}] 15s 选项已注入菜单`);
    syncMenuCheckmark(durationMenu);
    patchDurationButton();
  }

  // 同步菜单勾选：如果设置是15s，在15s项上显示勾选，隐藏其他项的勾选
  // 安全版本：不移动 SVG（结构性修改会导致 React 协调崩溃）
  // 只做：1) 克隆 SVG 加到 15s  2) 给原 SVG 加 visibility:hidden（样式修改，React 能容忍）
  function syncMenuCheckmark(menu) {
    if (targetDuration !== 15) return;

    const items = menu.querySelectorAll('[role="menuitem"]');
    let item15s = null;
    let checkedSvg = null;
    let checkedItem = null;

    for (const item of items) {
      const text = item.textContent.trim();
      if (text === '15s') {
        item15s = item;
        continue;
      }
      // 在 5s/10s 项中查找当前有勾选的
      const svg = item.querySelector('svg');
      if (svg && !checkedSvg) {
        checkedSvg = svg;
        checkedItem = item;
      }
    }

    if (!item15s) return;
    if (!checkedSvg) return;

    // 15s 已有勾选则只需确保原勾选隐藏
    if (item15s.querySelector('svg')) {
      checkedSvg.style.visibility = 'hidden';
      return;
    }

    function getPath(el, root) {
      const path = [];
      while (el && el !== root) {
        const parent = el.parentElement;
        if (!parent) break;
        const index = Array.from(parent.children).indexOf(el);
        path.unshift(index);
        el = parent;
      }
      return path;
    }

    function getElByPath(root, path) {
      let el = root;
      for (const idx of path) {
        if (!el.children[idx]) return null;
        el = el.children[idx];
      }
      return el;
    }

    const svgPath = getPath(checkedSvg, checkedItem);
    let added = false;

    if (svgPath.length >= 2) {
      const targetParent = getElByPath(item15s, svgPath.slice(0, -1));
      if (targetParent) {
        targetParent.appendChild(checkedSvg.cloneNode(true));
        added = true;
      }
    }

    if (!added) {
      item15s.appendChild(checkedSvg.cloneNode(true));
    }

    // 关键：不 remove() 原 SVG（那是结构性修改，React 会崩溃）
    // 只是隐藏它（样式修改，React 不会因为多了个 visibility 样式就崩溃）
    checkedSvg.style.visibility = 'hidden';
    console.log(`[${PLUGIN_ID}] 勾选已同步到 15s（安全版：克隆+隐藏原勾选）`);
  }

  // 修正时长按钮显示（菜单关闭后的按钮文字）
  // 方案：给原 "10s" 文本加 opacity:0 隐藏，叠加浮动元素显示 "15s"
  // 只改样式，不改结构，React 不会崩溃
  let overlayEl = null;
  let overlayRafId = null;
  let hiddenTextEl = null;

  function findDurationTextEl() {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode: (node) => {
        if (node.textContent.trim() === '10s') return NodeFilter.FILTER_ACCEPT;
        return NodeFilter.FILTER_REJECT;
      }
    });
    let node;
    while ((node = walker.nextNode())) {
      const el = node.parentElement;
      if (!el) continue;
      if (el.closest('[role="menu"]') || el.closest('[role="menuitem"]')) continue;
      const rect = el.getBoundingClientRect();
      if (rect.width < 10 || rect.height < 10) continue;
      return el;
    }
    return null;
  }

  function updateOverlayPosition() {
    if (targetDuration !== 15) {
      if (overlayEl) overlayEl.style.display = 'none';
      if (hiddenTextEl) {
        hiddenTextEl.style.opacity = '';
        hiddenTextEl = null;
      }
      return;
    }

    const textEl = findDurationTextEl();
    if (!textEl) {
      if (overlayEl) overlayEl.style.display = 'none';
      if (hiddenTextEl) {
        hiddenTextEl.style.opacity = '';
        hiddenTextEl = null;
      }
      overlayRafId = requestAnimationFrame(updateOverlayPosition);
      return;
    }

    // 隐藏原 "10s" 文字（只改 opacity，样式修改，React 能容忍）
    if (hiddenTextEl !== textEl) {
      if (hiddenTextEl) hiddenTextEl.style.opacity = '';
      textEl.style.opacity = '0';
      hiddenTextEl = textEl;
    }

    if (!overlayEl) {
      overlayEl = document.createElement('div');
      overlayEl.className = 'seedance-15s-button-overlay';
      overlayEl.textContent = '15s';
      overlayEl.style.pointerEvents = 'none';
      overlayEl.style.zIndex = '999999';
      overlayEl.style.position = 'fixed';
      overlayEl.style.display = 'flex';
      overlayEl.style.alignItems = 'center';
      overlayEl.style.justifyContent = 'center';
      overlayEl.style.whiteSpace = 'nowrap';
      overlayEl.style.boxSizing = 'border-box';
      document.body.appendChild(overlayEl);
    }

    const textRect = textEl.getBoundingClientRect();
    const textCs = getComputedStyle(textEl);

    overlayEl.style.display = 'flex';
    overlayEl.style.top = textRect.top + 'px';
    overlayEl.style.left = textRect.left + 'px';
    overlayEl.style.width = textRect.width + 'px';
    overlayEl.style.height = textRect.height + 'px';
    overlayEl.style.fontSize = textCs.fontSize;
    overlayEl.style.fontWeight = textCs.fontWeight;
    overlayEl.style.color = textCs.color;
    overlayEl.style.fontFamily = textCs.fontFamily;
    overlayEl.style.lineHeight = textCs.lineHeight;
    overlayEl.style.letterSpacing = textCs.letterSpacing;
    overlayEl.style.backgroundColor = 'transparent';

    overlayRafId = requestAnimationFrame(updateOverlayPosition);
  }

  function patchDurationButton() {
    if (targetDuration !== 15) return;
    if (overlayRafId) return;
    updateOverlayPosition();
  }

  function clearDurationButtonPatch() {
    if (overlayRafId) {
      cancelAnimationFrame(overlayRafId);
      overlayRafId = null;
    }
    if (overlayEl) {
      overlayEl.style.display = 'none';
    }
    if (hiddenTextEl) {
      hiddenTextEl.style.opacity = '';
      hiddenTextEl = null;
    }
  }

  let domObserverTimer = null;
  function handleDomChange() {
    if (domObserverTimer) clearTimeout(domObserverTimer);
    domObserverTimer = setTimeout(() => {
      if (isEnabled) {
        inject15sOption();
      } else {
        remove15sOption();
      }
    }, 150);
  }

  const domObserver = new MutationObserver(handleDomChange);
  domObserver.observe(document.documentElement, {
    childList: true,
    subtree: true
  });

  setTimeout(() => {
    if (isEnabled) inject15sOption();
  }, 2000);

  // ========== 5. 媒体 URL 监听 ==========
  function extractMediaFromResponse(data) {
    try {
      const str = JSON.stringify(data);
      const imgMatches = str.match(/https?:\/\/[^"]*byteimg\.com[^"]*\.(?:jpg|jpeg|png|webp)/g);
      if (imgMatches) {
        imgMatches.forEach(url => {
          // stored for potential use
        });
      }
    } catch (e) {}
  }

  // ========== 6. 监听来自 popup 的消息 ==========
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'dbx-seed-toggle') {
      syncDurationConfig();
      sendResponse({ ok: true });
    }
    return true;
  });

  console.log(`[${PLUGIN_ID}] content.js 初始化完成`);
})();
