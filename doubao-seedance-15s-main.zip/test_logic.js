// test_logic.js - 纯 Node.js 逻辑测试（不依赖 DOM）
// 验证 content.js 修复后的关键算法逻辑

const assert = require('assert');

let passed = 0, failed = 0;
const asyncTests = [];
function test(name, fn) {
  const isAsync = fn.length >= 1;
  if (isAsync) {
    asyncTests.push(new Promise(resolve => {
      try {
        fn(() => { passed++; console.log('  PASS ' + name); resolve(); });
      } catch (e) {
        failed++; console.log('  FAIL ' + name + ' — ' + e.message); resolve();
      }
    }));
    return;
  }
  try {
    const r = fn();
    if (r && typeof r.then === 'function') {
      asyncTests.push(r.then(() => { passed++; console.log('  PASS ' + name); })
        .catch(e => { failed++; console.log('  FAIL ' + name + ' — ' + e.message); }));
      return;
    }
    console.log('  PASS ' + name);
    passed++;
  } catch (e) {
    console.log('  FAIL ' + name + ' — ' + e.message);
    failed++;
  }
}

console.log('===== 测试 syncMenuCheckmark 逻辑 =====');

// 模拟 syncMenuCheckmark 的核心逻辑
function syncMenuCheckmarkLogic(items, targetDuration) {
  // items: [{ text: '5s', hasSvg: bool }, { text: '10s', hasSvg: bool }, { text: '15s', hasSvg: bool }]
  if (targetDuration !== 15) return { action: 'none', reason: 'targetDuration !== 15' };

  let item15s = null, checkedItem = null;
  for (const item of items) {
    if (item.text === '15s') { item15s = item; continue; }
    if (item.hasSvg && !checkedItem) { checkedItem = item; }
  }

  if (!item15s) return { action: 'none', reason: 'no 15s item' };
  if (item15s.hasSvg) return { action: 'none', reason: '15s already checked' };
  if (!checkedItem) return { action: 'none', reason: 'no checked item' };

  // 移动勾选
  checkedItem.hasSvg = false;
  item15s.hasSvg = true;
  return { action: 'moved', from: checkedItem.text, to: '15s' };
}

test('场景1: 勾选在 10s，应移到 15s', () => {
  const items = [
    { text: '5s', hasSvg: false },
    { text: '10s', hasSvg: true },
    { text: '15s', hasSvg: false }
  ];
  const r = syncMenuCheckmarkLogic(items, 15);
  assert.strictEqual(r.action, 'moved');
  assert.strictEqual(r.from, '10s');
  assert.strictEqual(items[2].hasSvg, true);
  assert.strictEqual(items[1].hasSvg, false);
});

test('场景2: 勾选在 5s，应移到 15s（之前修复不支持，现在支持）', () => {
  const items = [
    { text: '5s', hasSvg: true },
    { text: '10s', hasSvg: false },
    { text: '15s', hasSvg: false }
  ];
  const r = syncMenuCheckmarkLogic(items, 15);
  assert.strictEqual(r.action, 'moved');
  assert.strictEqual(r.from, '5s');
  assert.strictEqual(items[2].hasSvg, true);
  assert.strictEqual(items[0].hasSvg, false);
});

test('场景3: 15s 已有勾选，不操作', () => {
  const items = [
    { text: '5s', hasSvg: false },
    { text: '10s', hasSvg: false },
    { text: '15s', hasSvg: true }
  ];
  const r = syncMenuCheckmarkLogic(items, 15);
  assert.strictEqual(r.action, 'none');
});

test('场景4: targetDuration 不是 15，不操作', () => {
  const items = [
    { text: '5s', hasSvg: false },
    { text: '10s', hasSvg: true },
    { text: '15s', hasSvg: false }
  ];
  const r = syncMenuCheckmarkLogic(items, 10);
  assert.strictEqual(r.action, 'none');
});

console.log('\n===== 测试 isSimulatingClick 时序逻辑 =====');

test('模拟点击期间 isSimulatingClick 为 true，150ms 后变 false', () => {
  let isSimulatingClick = false;
  isSimulatingClick = true;
  assert.strictEqual(isSimulatingClick, true);
  isSimulatingClick = false;
  assert.strictEqual(isSimulatingClick, false);
});

test('只有 10s 监听器受 isSimulatingClick 影响，5s 不受（快速切换关键修复）', () => {
  let isSimulatingClick = false;
  let targetDuration = 15;
  let eventLog = [];

  // 模拟 5s 监听器：不检查 isSimulatingClick
  function on5sClick() {
    targetDuration = 5;
    eventLog.push('5s handler ran');
  }

  // 模拟 10s 监听器：检查 isSimulatingClick
  function on10sClick() {
    if (isSimulatingClick) { eventLog.push('10s handler skipped'); return; }
    targetDuration = 10;
    eventLog.push('10s handler ran');
  }

  // 场景 1: isSimulatingClick=false，两个监听器都正常工作
  isSimulatingClick = false;
  on5sClick();
  assert.strictEqual(targetDuration, 5, '5s 监听器应正常执行');
  assert.deepStrictEqual(eventLog, ['5s handler ran']);

  targetDuration = 15;
  eventLog = [];
  on10sClick();
  assert.strictEqual(targetDuration, 10, '10s 监听器应正常执行');
  assert.deepStrictEqual(eventLog, ['10s handler ran']);

  // 场景 2: isSimulatingClick=true（模拟 15s 点击后的 150ms 窗口）
  // 10s 监听器应被跳过（因为是模拟点击）
  targetDuration = 15;
  eventLog = [];
  isSimulatingClick = true;
  on10sClick();
  assert.strictEqual(targetDuration, 15, '10s 监听器在 isSimulatingClick 时应被跳过');
  assert.deepStrictEqual(eventLog, ['10s handler skipped']);

  // 关键！ 5s 监听器不应被跳过（用户真实点击 5s）
  eventLog = [];
  on5sClick();
  assert.strictEqual(targetDuration, 5, '5s 监听器在 isSimulatingClick 时也应正常执行（用户真实点击）');
  assert.deepStrictEqual(eventLog, ['5s handler ran']);
});

test('快速切换场景：15s → 快速点击 5s，targetDuration 应正确变为 5', () => {
  // 模拟快速切换时序
  let isSimulatingClick = false;
  let targetDuration = 15;
  let injectDuration = 15; // 模拟 inject.js 的 targetDuration
  let requestModified = false;

  // 模拟 15s 点击
  function click15s() {
    targetDuration = 15;
    injectDuration = 15;
    isSimulatingClick = true;
    // 模拟点击 10s（被 isSimulatingClick 跳过）
    // 10s handler skipped
    // 150ms 后重置 isSimulatingClick
    setTimeout(() => { isSimulatingClick = false; }, 150);
  }

  // 模拟 5s 点击（不检查 isSimulatingClick）
  function click5s() {
    targetDuration = 5;
    injectDuration = 5; // 真实点击应更新 inject.js 的 duration
  }

  // 模拟 fetch hook（inject.js 中）
  function fetchHook(requestDuration) {
    if (injectDuration === 15) {
      requestModified = true;
      return 15; // 修改为 15s
    }
    return requestDuration;
  }

  // 快速切换：点击 15s 后立即点击 5s（在 150ms 窗口内）
  click15s();
  click5s(); // 在 isSimulatingClick=true 期间点击 5s

  // 验证：targetDuration 应为 5（因为 5s 监听器不检查 isSimulatingClick）
  assert.strictEqual(targetDuration, 5, '快速切换后 targetDuration 应为 5');
  assert.strictEqual(injectDuration, 5, '快速切换后 inject.js 的 duration 应为 5');

  // 验证：5s 的请求不应被修改
  requestModified = false;
  const result = fetchHook(5);
  assert.strictEqual(result, 5, '5s 请求不应被修改为 15s');
  assert.strictEqual(requestModified, false, 'requestModified 应为 false');
});

console.log('\n===== 测试 patchDurationButton 时序逻辑 =====');

test('多次延迟 patch 能覆盖异步更新', () => {
  // 同步验证：豆包重置文字后，patch 能重新修正
  let buttonText = '10s';
  // 模拟 patch
  function patch() { if (buttonText === '10s') buttonText = '15s'; }
  // 模拟豆包重置
  function doubaoReset() { buttonText = '10s'; }

  patch(); // 第一次 patch: 10s -> 15s
  assert.strictEqual(buttonText, '15s');
  doubaoReset(); // 豆包重置: 15s -> 10s
  assert.strictEqual(buttonText, '10s');
  patch(); // 再次 patch: 10s -> 15s
  assert.strictEqual(buttonText, '15s');
});

console.log('\n===== 测试 CSS 覆盖方案（不修改文本节点）=====');

test('patchDurationButton 只添加 CSS class，不修改文本节点', () => {
  // 模拟按钮元素
  const btnEl = {
    textContent: '10s',
    classList: { _classes: [], add(c) { this._classes.push(c); }, contains(c) { return this._classes.includes(c); }, remove(c) { this._classes = this._classes.filter(x => x !== c); } }
  };

  // 模拟新的 patchDurationButton 逻辑
  function patchDurationButton() {
    if (btnEl.classList.contains('seedance-btn-15s-overlay')) return;
    btnEl.classList.add('seedance-btn-15s-overlay');
  }

  patchDurationButton();
  // 关键验证：文本节点未被修改！
  assert.strictEqual(btnEl.textContent, '10s', '文本节点必须保持 10s（不修改，避免 React 协调失败）');
  assert.ok(btnEl.classList.contains('seedance-btn-15s-overlay'), '应添加 CSS class');
});

test('clearDurationButtonPatch 只移除 CSS class，不修改文本节点', () => {
  const btnEl = {
    textContent: '10s', // 文本始终保持 10s
    classList: { _classes: ['seedance-btn-15s-overlay'], add(c) { this._classes.push(c); }, contains(c) { return this._classes.includes(c); }, remove(c) { this._classes = this._classes.filter(x => x !== c); } }
  };

  function clearDurationButtonPatch() {
    btnEl.classList.remove('seedance-btn-15s-overlay');
  }

  clearDurationButtonPatch();
  // 关键验证：文本节点始终未被修改
  assert.strictEqual(btnEl.textContent, '10s', '文本节点必须始终保持 10s');
  assert.ok(!btnEl.classList.contains('seedance-btn-15s-overlay'), 'CSS class 应被移除');
});

test('React 协调安全：切换 5s 时文本节点始终是 10s，不会触发协调错误', () => {
  // 模拟 React 期望的文本
  let reactExpectedText = '10s';
  let reactReconcileError = false;

  const btnEl = {
    textContent: '10s',
    classList: { _classes: [], add(c) { this._classes.push(c); }, contains(c) { return this._classes.includes(c); }, remove(c) { this._classes = this._classes.filter(x => x !== c); } }
  };

  // 模拟 React 协调检查
  function reactReconcile() {
    if (btnEl.textContent !== reactExpectedText) {
      reactReconcileError = true; // 协调失败！
    }
  }

  // 场景：15s 时添加 CSS 覆盖
  btnEl.classList.add('seedance-btn-15s-overlay');
  // React 期望 10s，实际也是 10s → 协调成功
  reactReconcile();
  assert.strictEqual(reactReconcileError, false, '15s 状态下 React 协调应成功（文本仍是 10s）');

  // 场景：切换到 5s，移除 CSS class
  btnEl.classList.remove('seedance-btn-15s-overlay');
  reactExpectedText = '5s'; // React 期望更新为 5s
  // 豆包 React 更新文本为 5s
  btnEl.textContent = '5s';
  reactReconcile();
  assert.strictEqual(reactReconcileError, false, '切换 5s 后 React 协调应成功（我们没改过文本）');
  assert.strictEqual(btnEl.textContent, '5s', '文本应为 5s');
});

test('旧方案对比：直接修改文本节点会导致 React 协调失败', () => {
  // 模拟旧方案（直接改文本）
  let reactExpectedText = '10s';
  let reactReconcileError = false;

  const btnEl = { textContent: '10s' };

  function reactReconcile() {
    if (btnEl.textContent !== reactExpectedText) {
      reactReconcileError = true;
    }
  }

  // 旧方案：直接改文本为 15s
  btnEl.textContent = '15s';
  // React 期望 10s，但实际是 15s → 协调失败！
  reactReconcile();
  assert.strictEqual(reactReconcileError, true, '旧方案（改文本）会导致 React 协调失败');

  // 这就是为什么切换 5s 时输入框消失的原因
});

console.log('\n===== 测试 native click 监听器逻辑 =====');

test('native click 时延迟 50ms 调用 clearDurationButtonPatch（避免竞态）', () => {
  // 模拟已 patch 的按钮（只有 CSS class，文本未改）
  const btnEl = {
    textContent: '10s', // 文本始终是 10s
    classList: { _classes: ['seedance-btn-15s-overlay'], add(c) { this._classes.push(c); }, contains(c) { return this._classes.includes(c); }, remove(c) { this._classes = this._classes.filter(x => x !== c); } }
  };
  let delayApplied = false;

  function clearDurationButtonPatch() {
    btnEl.classList.remove('seedance-btn-15s-overlay');
  }

  function nativeClickHandler() {
    setTimeout(() => {
      clearDurationButtonPatch();
      delayApplied = true;
    }, 50);
  }

  nativeClickHandler();
  // 立即检查：CSS class 仍在（不应同步移除）
  assert.ok(btnEl.classList.contains('seedance-btn-15s-overlay'), '不应同步移除 CSS class');
  assert.strictEqual(delayApplied, false, '不应同步执行清理');
  assert.strictEqual(btnEl.textContent, '10s', '文本始终是 10s');
});

console.log('\n===== 测试 reinstallFetchHook 动态 duration (DOM 跨世界通信) =====');

test('reinstallFetchHook 从 DOM attribute 读取 duration（跨 isolated/MAIN world）', () => {
  // 模拟 document.documentElement
  const fakeDocEl = { _attr: '15', getAttribute(n) { return this._attr; }, setAttribute(n, v) { this._attr = v; } };

  // 模拟 MAIN world hook 读取逻辑
  function hookedFetchReadDur() {
    var durAttr = fakeDocEl.getAttribute('data-seedance-duration');
    var dur = durAttr === '5' ? 5 : durAttr === '10' ? 10 : 15;
    return dur;
  }

  // 初始为 15
  assert.strictEqual(hookedFetchReadDur(), 15, '初始应为 15');
  // content.js 切换到 5（写入 DOM attribute）
  fakeDocEl.setAttribute('data-seedance-duration', '5');
  assert.strictEqual(hookedFetchReadDur(), 5, 'MAIN world 应能读取到 5');
  // 切换到 10
  fakeDocEl.setAttribute('data-seedance-duration', '10');
  assert.strictEqual(hookedFetchReadDur(), 10, 'MAIN world 应能读取到 10');
  // 切换回 15
  fakeDocEl.setAttribute('data-seedance-duration', '15');
  assert.strictEqual(hookedFetchReadDur(), 15, 'MAIN world 应能读取到 15');
});

test('reinstallFetchHook 在 5s 时不修改请求体（DOM 通信修复后）', () => {
  // 模拟 document.documentElement，duration 为 5
  const fakeDocEl = { getAttribute(n) { return '5'; } };
  const requestBody = '{"ability_param":{"duration":5}}';

  function modifyBody(bodyStr) {
    var durAttr = fakeDocEl.getAttribute('data-seedance-duration');
    var dur = durAttr === '5' ? 5 : durAttr === '10' ? 10 : 15;
    if (dur !== 15) return bodyStr; // 不修改
    return bodyStr.replace(/\d+/, dur);
  }

  const result = modifyBody(requestBody);
  assert.strictEqual(result, requestBody, '5s 时不应修改请求体');
});

test('旧 bug 验证: window 变量在 MAIN world 不可见（说明为何要用 DOM）', () => {
  // 模拟 isolated world 设置 window 变量
  const isolatedWindow = { __seedance_target_duration: 5 };
  // MAIN world 的 window 是不同的对象（隔离）
  const mainWorldWindow = {};

  // MAIN world 读取 window 变量 → undefined（隔离）
  var dur = mainWorldWindow.__seedance_target_duration || 15;
  assert.strictEqual(dur, 15, 'MAIN world 读 isolated world 的 window 变量应得 undefined，回退到 15（这就是 bug）');

  // 但 DOM 是共享的
  const sharedDocEl = { _attr: '5', getAttribute() { return this._attr; } };
  var durAttr = sharedDocEl.getAttribute('data-seedance-duration');
  var dur2 = durAttr === '5' ? 5 : durAttr === '10' ? 10 : 15;
  assert.strictEqual(dur2, 5, 'DOM attribute 在两个世界共享，应能正确读取 5');
});

console.log('\n===== 测试 setTargetDuration 同步 DOM attribute =====');

test('setTargetDuration 同步更新 DOM attribute', () => {
  let targetDuration = 15;
  const fakeDocEl = { _attr: '15', getAttribute(n) { return this._attr; }, setAttribute(n, v) { this._attr = String(v); } };

  function setTargetDuration(d) {
    targetDuration = d;
    fakeDocEl.setAttribute('data-seedance-duration', String(d));
  }

  setTargetDuration(5);
  assert.strictEqual(targetDuration, 5);
  assert.strictEqual(fakeDocEl.getAttribute('data-seedance-duration'), '5', 'DOM attribute 应同步更新');

  setTargetDuration(10);
  assert.strictEqual(targetDuration, 10);
  assert.strictEqual(fakeDocEl.getAttribute('data-seedance-duration'), '10');

  setTargetDuration(15);
  assert.strictEqual(targetDuration, 15);
  assert.strictEqual(fakeDocEl.getAttribute('data-seedance-duration'), '15');
});

// 输出测试结果
console.log('\n===== 测试结果 =====');
console.log('通过: ' + passed + ', 失败: ' + failed);
process.exit(failed > 0 ? 1 : 0);
